
import difflib
from bs4 import BeautifulSoup

def extract_content(file_path):
    """Separates main text from footnotes and returns both."""
    with open(file_path, 'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f.read(), 'html.parser')
        
        footnotes = []
        # 1. Find all specific footnote spans
        for note in soup.find_all('span', class_='footnote'):
            # Extract the text and clean up its spacing
            clean_note = ' '.join(note.get_text(separator=' ').split())
            footnotes.append(clean_note)
            # Destroy the tag so it disappears from the main document tree
            note.decompose() 
            
        # 2. Extract the remaining main text (now footnote-free)
        raw_main_text = soup.get_text(separator=' ')
        main_text = ' '.join(raw_main_text.split())
        
        return main_text, footnotes

def generate_inline_diff(text1, text2):
    """Compares two strings and returns the HTML Track Changes formatting."""
    matcher = difflib.SequenceMatcher(None, text1, text2, autojunk=False)
    html_parts = []
    
    for opcode, a0, a1, b0, b1 in matcher.get_opcodes():
        if opcode == 'equal':
            html_parts.append(text1[a0:a1])
        elif opcode == 'insert':
            html_parts.append(f'<span style="background-color: #e6ffe6; font-weight: bold; padding: 2px;">{text2[b0:b1]}</span>')
        elif opcode == 'delete':
            html_parts.append(f'<span style="background-color: #ffe6e6; text-decoration: line-through; padding: 2px;">{text1[a0:a1]}</span>')
        elif opcode == 'replace':
            html_parts.append(f'<span style="background-color: #ffe6e6; text-decoration: line-through; padding: 2px;">{text1[a0:a1]}</span>')
            html_parts.append(f'<span style="background-color: #e6ffe6; font-weight: bold; padding: 2px;">{text2[b0:b1]}</span>')
            
    return ''.join(html_parts)

def compare_html_with_notes(file1_path, file2_path, output_path):
    try:
        # Get the separated text and footnotes from both files
        main1, notes1 = extract_content(file1_path)
        main2, notes2 = extract_content(file2_path)
        
        # 1. Compare the main body text
        main_diff_html = generate_inline_diff(main1, main2)
        
        # 2. Compare the footnotes sequentially
        # Find out which document has more footnotes so we don't miss any
        max_notes = max(len(notes1), len(notes2))
        notes_diff_html = []
        
        for i in range(max_notes):
            # If a note exists, grab it. If not (e.g., a note was added/deleted), use blank text
            n1 = notes1[i] if i < len(notes1) else ""
            n2 = notes2[i] if i < len(notes2) else ""
            
            note_diff = generate_inline_diff(n1, n2)
            # Wrap each compared note in a list item tag
            notes_diff_html.append(f'<li style="margin-bottom: 10px;">{note_diff}</li>')
        
        # 3. Build the final HTML document
        final_html = [
            '<html><body style="font-family: Georgia, serif; line-height: 2; padding: 40px; max-width: 900px; margin: auto; font-size: 18px;">',
            '<h2>Main Text Revisions</h2>',
            '<p><strong><span style="background-color: #ffe6e6; text-decoration: line-through; padding: 2px;">Red Strikethrough</span></strong> = Deleted<br>',
            '<strong><span style="background-color: #e6ffe6; padding: 2px;">Green Highlight</span></strong> = Added</p><hr>',
            f'<p>{main_diff_html}</p>',
            '<hr style="margin-top: 40px; margin-bottom: 20px;">',
            '<h3>Footnote Revisions</h3>',
            '<ol>' + ''.join(notes_diff_html) + '</ol>', # Automatically numbers the footnotes
            '</body></html>'
        ]
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(''.join(final_html))
            
        print(f"Success! Open '{output_path}' to see the main text and footnotes separated.")

    except FileNotFoundError as e:
        print(f"Error: Could not find the file. {e}")
    except ModuleNotFoundError:
        print("Error: BeautifulSoup is not installed.")

# --- Run the program ---
file_a = 'LB00-1_PREF.html' 
file_b = 'LB02-1_PREF.html'
final_output = 'track_changes_report.html'

compare_html_with_notes(file_a, file_b, final_output)